console.log("page loaded...");

function controlsUp(element) {
    element.play()
    element.muted

}

function controlsDown(element) {
    element.pause()
}